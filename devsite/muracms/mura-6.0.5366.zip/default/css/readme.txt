The files found here are shared by themes and provide necessary styles for Mura default output and objects. Specifically, these are:

- reset.css
- default.css
- shadowbox.css